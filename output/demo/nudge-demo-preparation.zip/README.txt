Open operations/field-card.pdf or operations/runbook.md offline.
Read operations/presenter-script.md and fill operations/onsite-record.template.md.
Task index: operations/issues.md; full scopes: operations/issue-bodies.md. No issue is assigned or device-verified by this kit.
source/ contains tracked firmware sources and pinned PlatformIO configuration only.
PlatformIO toolchains/library caches and an offline installer are NOT included.
Bring the already configured laptop; fresh-computer flashing is unverified.
Historical upstream README links may require network; the operation card itself does not.
No real backup video exists yet. Do not present a software preview as physical footage.
Integrity: python3 tools/build_demo_kit.py verify /path/to/this.zip
