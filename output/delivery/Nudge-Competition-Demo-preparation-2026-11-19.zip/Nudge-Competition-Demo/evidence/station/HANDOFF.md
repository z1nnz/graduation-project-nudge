# Device handoff - station（待實機驗收）

裝置：station
負責人：roy (default; physical deferred)
硬體型號：XIAO ESP32-S3 (confirm physical identity) / Waveshare 17344 ST7789V/VW 240x320; wiring unconfirmed
PlatformIO environment：station_p0a
Source commit：c4cb9fa3b7a919f1c888bf79b10a011d94c4fb0f
Binary 路徑：binaries/station_demo/station_p0a_unconfigured.bin
Binary SHA-256：c8cacd205cd95c0ce9dadfcdee5fd43ba2177ee5ff03c5179b0d95414cd6fc38
Profile SHA-256：942a127a4f05282afe5d1174436e640db63eb596e927381ca2a4e99db86a8cd2
燒錄命令：尚未執行；Station 獨立主控／GPIO 未確認，不執行 upload。
正常開機畫面：source 預期 Boot／Home，實際未驗。
Next 操作：未驗；不把 source 的 Serial N 當已驗按鍵。
Restart 操作：未驗；USB 斷電 5 秒再接是操作計畫，長按尚未驗。
Auto Demo：source 有自動三幕／八幕，實物未驗。
P1 周邊：OFF，未採。
離線狀態：source 無需 App／Cloud，實物未驗。
已知限制：候選 application image，不是已驗收發布，Station 接線未配置。
最後實機驗收日期：未驗。
驗收影片：未拍。
Demo data：共用 evidence/demo-data.json，虛構小樹／小芽／82 分等固定資料。
